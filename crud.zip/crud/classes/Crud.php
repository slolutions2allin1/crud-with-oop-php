<?php 
    class Crud extends Db {
        
        public function index() {
            $sql = "select * from crud.users";
            $stmt = $this->con()->query($sql);
            $results = $stmt->fetchAll(PDO::FETCH_OBJ);
            return $results;
        }
        
        // public function insertValidation($data) {
        //     $error = array();
        //     if(empty($data['user'])) 
        //         $error['user'] = "The User ID field must be filled in. Thank you."; 
        //     else {
        //         $sql = "select user from crud.users where user = :user"; 
                
        //         $stmt = $this->con()->prepare($sql);
        //         $stmt->bindValue(":user", $data['user']); 
        //         $stmt->execute();
        //         $row = $stmt->rowCount();
        //         if($row)
        //             $error['user'] = "The User ID you entered has already been used. Pleas try a different one. Thank you.";
        //     }
        //     if(strlen($data['phone']) != 11 && $data['phone'] != "")
        //         $error['phone'] = "The phone number must be exactly eleven(11) digits long. Thank you";
        //     else {
        //         $sql = "select phone from crud.users where phone = :phone"; 
        //         $stmt = $this->con()->prepare($sql);
        //         $stmt->bindValue(":phone", $data['phone']); 
        //         $stmt->execute();
        //         $row = $stmt->rowCount();
        //         if($row)
        //             $error['phone'] = "The Phone NUmber you entered has already been used. Pleas try a different one. Thank you.";
        //     }
        //     if(!filter_var($data['email'], FILTER_VALIDATE_EMAIL) && $data['email'] != "") 
        //         $error['email'] = "Please enter a valid email address. Thank you.";
        //     else {
        //         $sql = "select email from crud.users where email = :email"; 
        //         $stmt = $this->con()->prepare($sql);
        //         $stmt->bindValue(":email", $data['email']); 
        //         $stmt->execute();
        //         $row = $stmt->rowCount();
        //         if($row)
        //             $error['email'] = "The E-mail Address you entered has already been used. Pleas try a different one. Thank you.";
        //         }

        //     return $error ? $error : false;

        // }

        public function validation($data) {
            $error = array();
            if(empty($data['user'])) 
                $error['user'] = "The User ID field must be filled in. Thank you."; 
            else {
                $sql = "select user from crud.users where user = :user && id <> :id"; 
                
                $stmt = $this->con()->prepare($sql);
                $stmt->bindValue(":user", $data['user']);
                $stmt->bindValue(":id", $data['id']); 
                $stmt->execute();
                $row = $stmt->rowCount();
                if($row) 
                    $error['user'] = "The User ID you entered has already been used. Pleas try a different one. Thank you.";
            }
            if(strlen($data['phone']) != 11 && $data['phone'] != "")
                $error['phone'] = "Please enter a valid phone number. Thank you";
            else {
                $sql = "select phone from crud.users where phone = :phone && id <> :id"; 
                $stmt = $this->con()->prepare($sql);
                $stmt->bindValue(":phone", $data['phone']);
                $stmt->bindValue(":id", $data['id']); 
                $stmt->execute();
                $row = $stmt->rowCount();
                if($row)
                    $error['phone'] = "The Phone NUmber you entered has already been used. Pleas try a different one. Thank you.";
            }
            if(!filter_var($data['email'], FILTER_VALIDATE_EMAIL) && $data['email'] != "") 
                $error['email'] = "Please enter a valid email address. Thank you.";
            else {
                $sql = "select email from crud.users where email = :email && id <> :id"; 
                $stmt = $this->con()->prepare($sql);
                $stmt->bindValue(":email", $data['email']); 
                $stmt->bindValue(":id", $data['id']);
                $stmt->execute();
                $row = $stmt->rowCount();
                if($row)
                    $error['email'] = "The E-mail Address you entered has already been used. Pleas try a different one. Thank you.";
            }

            return $error ? $error : false;

        }

        public function insert($data) {
            
            if($this->validation($data)) {
                return $error = $this->validation($data);
            } else {
                $columns = implode(', ', array_keys($data));
                $placeholder = implode(", :", array_keys($data));
                $sql = "insert into crud.users($columns) values(:$placeholder )";
                $stmt = $this->con()->prepare($sql);
            
                foreach( $data as $key => $value) {
                    $stmt->bindValue(':' . $key, $value);
                }
                $result = $stmt->execute();
                if($result) {
                    header('location:index.php');
                }
            }  
        }

        public function edit($id) {

            if($id) {
                $sql = "select * from crud.users where id = :id";
                $stmt = $this->con()->prepare($sql);
                $stmt->bindValue(":id", $id);
                $stmt->execute();
                $result = $stmt->fetch(PDO::FETCH_ASSOC);
                return $result;
            }
        }

        public function update($data) {

            if($this->validation($data)) {
                $error = $this->validation($data);
                return $error;
            }else {
                $sql = "update crud.users set user = :user, name = :name, email = :email, phone = :phone, address = :address where id = :id";
                $stmt = $this->con()->prepare($sql);
                foreach($data as $k => $v) {
                    $stmt->bindValue(":".$k, $v);
                }
                $result = $stmt->execute();
                if($result) {
                    header('location:index.php');
                }
            }
            
        }

        public function delete($id) {
            $sql = "delete from crud.users where id = :id";
            $stmt = $this->con()->prepare($sql);
            $stmt->bindValue(":id", $id);
            $stmt->execute();
        }
    }
?>