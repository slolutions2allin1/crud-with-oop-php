<?php 
    class Admin extends Db {
        public function login($data) {
            if(empty($data['user']) && empty($data['password'])) {
                echo "Please submit your login information. Thank you.";
            }else {
 
                $sql = "Select * from crud.admins where user = :user and password = :password";
                $stmt = $this->con()->prepare($sql);
                    foreach($data as $k => $v) {
                        $stmt->bindValue(":" . $k, $v);
                    }
                $stmt->execute();
                // $rows = $stmt->fetchAll(PDO::FETCH_OBJ);
                // $data = $rows->rowCount();
                $row = $stmt->rowCount();
                if($row > 0) {
                    // echo $row;
                    $_SESSION['user'] = $data['user'];
                    header('location:index.php');
                    exit();
                }else {
                    echo "Please login with correct user id and password. Thank you.";
                }
                
            }
        }
    }
?>