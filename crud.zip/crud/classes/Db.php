<?php 
    class Db {
        protected function con() {
            try {
                $db = new PDO('mysql:host:localhost;dbname=crud', 'root', '');
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            }catch(PDOException $e) {
                echo "Db connection failed!" . $e->getMessage();
            }

            return $db;
        }
    }
?>