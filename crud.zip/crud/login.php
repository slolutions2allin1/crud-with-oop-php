<?php 

    session_start();

    function __autoload($class) {
        require_once "classes/$class.php";
    }

    if(isset($_POST['login'])) {
        $data = array();
        $data['user'] = $_POST['user']; 
        $data['password'] = $_POST['password'];
        
        $admin = new Admin;
        $admin->login($data);
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>Login Please...</h1>
    <form action="" method="post">
    <p> <input type="text" name="user"> </p>
    <p> <input type="password" name="password" /> </p>
    <input type="submit" name="login" value="login" />
    </form>
</body>
</html>