<?php
    session_start();
    // error_reporting(0);
    function __autoload($class) {
        require_once "classes/$class.php";
    }

    if($_SESSION['user'] == true) {

    }else{
        header('location:login.php');
    }

    if($_GET['id']) {
        $id = $_GET['id'];
        $crud = new Crud;
        $result = $crud->edit($id);   
    }

    if(isset($_POST['update'])) {
        $data = array();
        $data['id'] = $_POST['id'];
        $data['user'] = $_POST['user'];
        $data['name'] = $_POST['name'];
        $data['email'] = $_POST['email'];
        $data['phone'] = $_POST['phone'];
        $data['address'] = $_POST['address'];
        // $data['image'] = $_POST['image'];
        if($result == true) {
            $error = $crud->update($data);
        }
    }

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Document</title>
    </head>
    <body>
        <br /> 
        <div style="float:right"> <a href="index.php">Index</a> &nbsp &nbsp <a href="logout.php">Logout</a></div>
        <br />
        <br /> 
        <h1>Update Operation: </h1>
        <br />
            <form action="" method="post" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?php echo $result['id']?>">
            <p> User ID: &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp <input type="text" name="user" value="<?php echo $result['user'] ?>"> <span style="color:red"><?php if(isset($error['user'])) echo $error['user'] ?><span> </p> 
            <P> User Name: &nbsp &nbsp &nbsp &nbsp <input type="text" name="name" value="<?php echo $result['name'] ?>"> </p>
            <p> User E-mail: &nbsp &nbsp &nbsp &nbsp <input type="text" name="email" value="<?php echo $result['email'] ?>"> <span style="color:red"><?php if(isset($error['email'])) echo $error['email'] ?><span> </p>
            <p> User Phone: &nbsp &nbsp &nbsp &nbsp  <input type="text" name="phone" value="<?php echo $result['phone'] ?>"> <span style="color:red"><?php if(isset($error['phone'])) echo $error['phone'] ?><span> </p>
            <p> User Address: &nbsp &nbsp &nbsp <textarea name="address" cols="30" rows="10" value="<?php echo $result['address'] ?>"> </textarea> </p>
            <input type="submit" name="update" value="Update Data">
            </form>
        </body>
</html>