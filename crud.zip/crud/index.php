<?php
    
    session_start();
    
    function __autoload($class) {
        require_once "classes/$class.php";
    }

    if($_SESSION['user'] == true) {

    }else{
        header('location:login.php');
    }
    
    $crud = new Crud;
    $results = $crud->index();
    

    if(!empty($_GET['id'])) {
        $id = $_GET['id'];
        $crud->delete($id);
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <br /> 
    <div style="float:right"> <a href="insert.php">Insert</a> &nbsp &nbsp
    <a href="logout.php">Logout</a></div>
    <br />
    <h1>Users Data: </h1>
    <br />
    <table border="1" style="border-collapse:collapse">
        <tr>
            <th>User_id</th>
            <th>User_Name</th>
            <th>User E-mail</th>
            <th>User Phone</th>
            <th>User Address</th>
            <th colspan="2" style="align:center">Actions</th>
        </tr>
        
        <?php 
            if($results == true) :
            foreach($results as $result) : 
        ?>
        <tr>
           <td><?php echo $result->user ?></td>
            <td><?php echo $result->name ?></td>
            <td><?php echo $result->email ?></td>
            <td><?php echo $result->phone ?></td>
            <td><?php echo $result->address ?></td>
            <td><a href="update.php?id=<?php echo $result->id ?>">Update</a> &nbsp <a href="index.php?id=<?php echo $result->id ?>">Delete</a></td>
        </tr> 
        <?php 
            endforeach; 
            endif; 
        ?> 
    </table>
</body>
</html>