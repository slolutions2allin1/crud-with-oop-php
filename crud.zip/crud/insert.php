<?php 
    session_start();
    error_reporting(0);
    function __autoload($class) {
        require_once "classes/$class.php";
    }

    if($_SESSION['user'] == true) {

    }else{
        header('location:login.php');
    }

    if(isset($_POST['insert'])) {
        $data = array();
        $data['user'] = $_POST['user'];
        $data['name'] = $_POST['name'];
        $data['email'] = $_POST['email'];
        $data['phone'] = $_POST['phone'];
        $data['address'] = $_POST['address'];
        
        $crud = new Crud;
        $error = $crud->insert($data);
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

<br /> 
<div style="float:right"> <a href="index.php">Index</a> &nbsp &nbsp <a href="logout.php">Logout</a></div>
<br />

<br /> 
<h1>Insert User Data: </h1>
<br />

<form action="" method="post" enctype="multipart/form-data">
        <p> User ID: &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp <input type="text" name="user" value="<?php if(isset($data['user'])) echo $data['user'] ?>"> <span style="color:red"><?php if(isset($error['user'])) echo $error['user'] ?><span> </p>
        <p>User Name: &nbsp &nbsp &nbsp &nbsp <input type="text" name="name" value="<?php if(isset($data['name'])) echo $data['name'] ?>"> </p>
        <p> User E-mail: &nbsp &nbsp &nbsp &nbsp <input type="text" name="email" value="<?php if(isset($data['email'])) echo $data['email'] ?>"> <span style="color:red"><?php if(isset($error['email'])) echo $error['email'] ?><span> </p>
        <p> User Phone: &nbsp &nbsp &nbsp &nbsp  <input type="text" name="phone" value="<?php if(isset($data['phone'])) echo $data['phone'] ?>"> <span style="color:red"><?php if(isset($error['phone'])) echo $error['phone'] ?><span> </p>
        <p> User Address: &nbsp &nbsp &nbsp <textarea name="address" cols="30" rows="10" value="<?php if(isset($data['address'])) echo $data['address'] ?>"></textarea> </p>
        <!-- User Picture:  &nbsp &nbsp <input type="file" name="file"><br /> <br /> -->
        <br /> <input type="submit" name="insert" value="Insert Data">
    </form>
</body>
</html>